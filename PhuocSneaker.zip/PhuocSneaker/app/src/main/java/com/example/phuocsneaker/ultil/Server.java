package com.example.phuocsneaker.ultil;

public class Server {
    public static String localhost = "127.0.0.1";
    public static String DuongdanLoaisp = "http://" + localhost + "/server/getloaisp.php";
    public static String Duongdansanphammoinhat = "http://" + localhost + "/server/getsanphammoinhat.php";
    public static String Duongdanadidas = "http://" + localhost + "/server/getsanpham.php?page=";
    public static String Duongdannike = "http://" + localhost + "/server/getsanphamnike.php?page=";
    public static String Duongdanfila = "http://" + localhost + "/server/getsanphamfila.php?page=";
    public static String Duongdandonhang = "http://" + localhost + "/server/thongtinkhachhang.php";
    public static String Duongdanchitietdonhang = "http://" + localhost + "/server/chitietdonhang.php";
}
/*public class Server {
    public static String localhost = "https://phuocsneaker.000webhostapp.com";
    public static String DuongdanLoaisp = localhost + "/getloaisp.php";
    public static String Duongdansanphammoinhat = localhost + "/getsanphammoinhat.php";
    public static String Duongdanadidas = localhost + "/getsanpham.php?page=";
    public static String Duongdannike = localhost + "/getsanphamnike.php?page=";
    public static String Duongdandonhang = localhost + "/thongtinkhachhang.php";
    public static String Duongdanchitietdonhang = localhost + "/chitietdonhang.php";
}*/
